package archiduchess.microservice_clientui;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceClientuiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceClientuiApplication.class, args);
	}

}
