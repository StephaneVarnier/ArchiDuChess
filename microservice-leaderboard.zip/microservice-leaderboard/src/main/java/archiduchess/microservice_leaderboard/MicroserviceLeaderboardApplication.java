package archiduchess.microservice_leaderboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceLeaderboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceLeaderboardApplication.class, args);
	}

}
